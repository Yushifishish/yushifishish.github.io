Cascadia Code Font

COPYRIGHT NOTICE:
This font is developed and copyrighted by Microsoft Corporation.

LICENSE:
Licensed under the SIL Open Font License 1.1 (OFL).

REDISTRIBUTION NOTICE:
This is a redistribution of the original font for use with the Scratch extension project.

YOUR RIGHTS UNDER OFL:
As a recipient of this redistributed font, you are granted the following permissions:

1. You may use this font for any purpose, personal or commercial.
2. You may study, modify, and adapt this font for your own use.
3. You may redistribute original or modified versions of this font.
4. You may embed this font in documents, software, websites, or other media.

YOUR OBLIGATIONS UNDER OFL:
When redistributing this font (original or modified), you must:

1. Keep the original copyright notice intact.
2. Include a copy of this license (LICENSE file) with any redistribution.
3. For modified versions, you must change the font name(s).
4. You may not sell the font file on its own.

RESTRICTED USES:
1. You may not use the name "Microsoft" or "Cascadia Code" to promote derivative works.
2. You may not sublicense or sell the font file as a standalone product.

ORIGINAL SOURCE:
https://github.com/microsoft/cascadia-code

FULL LICENSE:
See the included LICENSE file for complete terms.

---
This redistribution is provided for convenience only.
All font copyrights remain with Microsoft Corporation